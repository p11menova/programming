package org.example;

import org.example.commands.*;
import org.example.models.Person;
import org.example.utility.*;

import java.time.LocalDateTime;
import java.util.Scanner;

/**
 * Главный класс запуска программы.
 */
public class Main {
    /**
     * Начинает выполнение менеджера запуска программы.
     * @param args
     */
    public static void main(String[] args) {
        RunManager.go();

    }
}


