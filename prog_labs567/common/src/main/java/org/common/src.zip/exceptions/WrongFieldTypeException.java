package org.example.exceptions;

/**
Исключение неверного типа данных поля. Выбрасывается при попытке задать полю значение не того типа.
 */
public class WrongFieldTypeException extends Exception{

}

